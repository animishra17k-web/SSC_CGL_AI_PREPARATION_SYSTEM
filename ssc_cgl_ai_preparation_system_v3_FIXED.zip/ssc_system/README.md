# SSC CGL AI Preparation OS — V3 (bug-fixed, cloud-ready)

This is your study system: you paste in source material (notes, PDFs, textbook
chapters), and it uses AI to break it into atomic facts, teaching notes,
flashcards, and exam-style questions — then tracks which topics and error
types you're weak in and tells you what to revise next.

**This copy has been repaired.** The version you uploaded had four real bugs
that would have stopped it from working even after a correct deployment. See
"What was actually broken" below if you want the details. Everything else in
this file is how to get it live on the internet, for free, without installing
anything permanently on your own computer.

---

## 1. How the pieces fit together (read this once, it removes 90% of the confusion)

You are not deploying "one thing." You are connecting four separate free
services, each doing one job:

| Service | What it does | Why you need it |
|---|---|---|
| **GitHub** | Stores your code (like Google Drive, but for code, with version history) | Render reads your code from here |
| **Render** | Runs your Python program 24/7 so a browser can reach it | This is "the server" — the actual app |
| **Supabase** | A database (a permanent filing cabinet for your subjects, topics, flashcards, test history) | Render's free tier forgets everything when it restarts, so the data has to live somewhere else |
| **OpenAI** | The AI that reads your notes and generates flashcards/questions/grading | This is the "brain" — it costs a small amount per use (see §5) |

Data flow once it's all connected:

```
You (Realme Pad / phone / laptop browser)
        │  opens a normal website URL
        ▼
   Render (runs your FastAPI app, 24/7)
        │                      │
        ▼                      ▼
  Supabase (Postgres)     OpenAI API (generates content, grades tests)
  stores everything          costs a few cents per action
  permanently
```

You will never touch a command line for the deployed version. You only use
each service's website.

---

## 2. What was actually broken (so you understand what changed)

You said it failed to run locally — this is almost certainly why:

1. **Login bug**: the app was supposed to skip the password prompt when you
   leave `APP_PASSWORD` blank (the normal setting for local use). Instead, a
   one-line mistake in the security code made *every single page* return
   "401 Unauthorized" — including the home page — no matter what. You'd have
   hit a browser login popup with no working credentials to enter. **Fixed.**
2. **`/static` folder was never connected to the app**, so icon files
   couldn't load even if they existed.
3. **The manifest and service-worker files were saved in the wrong folder**
   relative to where the code looked for them — `/manifest.json` and
   `/sw.js` both returned server errors. This is also why "Install on
   tablet" could never have worked, even on a correct deployment. **Fixed**,
   and I also generated real app icons (the originals were an empty list).
4. **The PDF export tool would crash** on any note containing the characters
   `<`, `>`, or a straight quote `"` — common in grammar and math notes.
   **Fixed.**
5. **Missing feature, not a bug**: your backend fully supported creating and
   AI-grading a test, but there was no button anywhere to actually take one.
   I added a "Take a test" screen so the full loop — build pack → take test →
   see AI error-analysis → weak topics rise in priority — now works end to
   end in the browser.
6. `requirements.txt` had no version numbers pinned, which is how a project
   "that worked yesterday" silently breaks after a library updates. I pinned
   every dependency to versions I've verified install and run together.
7. `.gitignore` didn't exclude the `.venv` folder (the local Python
   environment folder), so uploading to GitHub as-is would have pushed
   thousands of unnecessary files.

None of this was you doing anything wrong — these are exactly the kind of
small mismatches that show up when a project is built quickly and never
actually run end-to-end.

---

## 3. Deploy it — step by step

Total time: 20–30 minutes. You need: an email address, and a debit/credit
card for the OpenAI step (OpenAI is not free — see §5 for real costs, which
are small).

### Step 1 — Get an OpenAI API key
Go to **platform.openai.com**, sign up, and add a payment method under
**Settings → Billing** (API access requires this; it is pay-as-you-go, not a
subscription). Then go to **API keys** and create a new key. Copy it
somewhere safe immediately — OpenAI only shows it to you once.

### Step 2 — Put this project on GitHub (no coding required)
Go to **github.com**, sign up for a free account. Click the **+** icon top
right → **New repository**. Name it (e.g. `ssc-cgl-ai-os`), keep it
**Private** (recommended, it's your personal study data), click **Create**.
On the next page click **uploading an existing file**, then drag the entire
unzipped project folder (everything you got from me) straight into the
browser window. GitHub preserves the folder structure automatically. Scroll
down and click **Commit changes**.

### Step 3 — Create a free database on Supabase
Go to **supabase.com**, sign up, click **New project**. Pick any name and a
strong database password (write it down). Wait ~2 minutes for it to
provision. Then go to **Project Settings → Database**, and copy the
**Connection string** under "Connection pooling" (URI format, starts with
`postgresql://`). This is your `DATABASE_URL`.

### Step 4 — Create the web service on Render
Go to **render.com**, sign up (you can sign up with your GitHub account,
which also connects them automatically). Click **New → Web Service**, pick
the GitHub repo you created in Step 2. Render will detect the `render.yaml`
file in the project and pre-fill most settings — confirm:
- **Build command**: `pip install -r requirements.txt`
- **Start command**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
- **Plan**: Free

### Step 5 — Set the environment variables
Still on Render, before (or right after) deploying, go to the **Environment**
tab and add:

| Key | Value |
|---|---|
| `AI_PROVIDER` | `openai` |
| `OPENAI_API_KEY` | *(the key from Step 1)* |
| `OPENAI_MODEL` | `gpt-4.1-mini` |
| `DATABASE_URL` | *(the connection string from Step 3)* |
| `APP_USERNAME` | `student` (or anything) |
| `APP_PASSWORD` | *(pick a real password — required for a public link, see §4)* |
| `EXAM_DATE` | your SSC CGL exam date, e.g. `2026-10-28` |

### Step 6 — Deploy
Click **Deploy** (or **Save, rebuild and deploy**). Watch the logs — the
first build takes 2–5 minutes. When it says your service is "Live," click the
`.onrender.com` URL Render gives you. You should see the app, and it will
ask for the username/password you set in Step 5.

### Step 7 — Install it on your Realme Pad
Open the same `.onrender.com` URL in Chrome on the tablet. Tap the **⋮** menu
→ **Add to Home screen** (or you'll see an install icon in the address bar).
It now behaves like a normal app icon, opening full-screen.

**One free-tier quirk to know**: Render's free web service goes to sleep
after 15 minutes with no visitors, and takes ~30–50 seconds to wake back up
on the next visit. That's normal, not broken — just wait for the first load.

---

## 4. About that password

Once deployed, your `.onrender.com` URL is technically reachable by anyone
who has it (it's on the public internet). `APP_PASSWORD` is your only
protection — always set a real one for anything beyond local testing. Never
commit your `.env` file or paste your OpenAI key into GitHub, screenshots, or
chat messages.

## 5. What this actually costs

Render's free web service and Supabase's free database are both genuinely
free for a personal project at this scale. **OpenAI is the one real cost**,
billed per use, no monthly fee:

- `gpt-4.1-mini` (recommended — good balance of quality and cost for
  structured extraction/grading tasks): **$0.40 per million input tokens,
  $1.60 per million output tokens** (OpenAI's published rate as of
  September 2026 — verify current pricing at
  `platform.openai.com/docs/pricing`, since it does change).
- In practice: building a full study pack (concepts → notes → flashcards →
  questions → validation) for one topic from a few pages of source material
  typically costs a few cents, not dollars. Grading one test costs a fraction
  of a cent.
- If you want it even cheaper, `gpt-4.1-nano` is about 4x cheaper again, at
  some quality cost — fine for straightforward topics.
- Set a spending limit under **Settings → Limits** on platform.openai.com so
  you can never be surprised by a bill.

## 6. Using it day to day

1. **Add a subject and topic** (e.g. English → Subject-Verb Agreement).
2. **Add a source**: paste text, or upload a PDF/DOCX of your notes/book
   chapter.
3. **Build the study pack**: this runs the full AI pipeline (extraction →
   teaching notes → flashcards → questions → validation) — takes 30–90
   seconds depending on source length.
4. **Take a test**: pick the topic and how many questions, answer them, and
   submit. The AI grades it and classifies *why* each answer was wrong
   (concept gap vs. careless mistake vs. vocabulary gap, etc.) — that
   classification is what feeds the weakness tracker.
5. **Check "Today's adaptive queue"**: topics with higher revision priority
   (weaker mastery) float to the top.
6. **Flashcard review**: a due-card queue with Again/Hard/Good/Easy ratings.
7. **Export**: Anki CSV export per topic, and a PDF of your notes, from the
   topic's export links.

## 7. If you ever want to run it locally too

```
# Mac/Linux
sh run_linux_mac.sh
# then:
uvicorn app.main:app --reload

# Windows
run_windows.bat
# then:
uvicorn app.main:app --reload
```

Leave `DATABASE_URL` blank in `.env` for local use — it automatically falls
back to a local SQLite file at `data/ssc_cgl.db`. Leave `APP_PASSWORD` blank
too (this now correctly skips the login prompt).

## 8. Troubleshooting

- **"Application failed to respond" right after deploying**: check the Render
  **Logs** tab — almost always a missing/misspelled environment variable
  (commonly `OPENAI_MODEL` or `DATABASE_URL`).
- **Build works but every page 401s**: you set `APP_PASSWORD` but are
  entering the wrong username — it must exactly match `APP_USERNAME`.
- **"Build pack" fails with a credentials error**: `OPENAI_API_KEY` is
  missing or wasn't saved — recheck the Environment tab on Render.
- **First load after inactivity is slow**: expected on Render's free tier
  (see §3, Step 7). Not an error.
- **Database resets / data disappeared**: this means `DATABASE_URL` is empty
  or wrong, so it silently fell back to Render's local SQLite file — which
  Render wipes on every restart. Double-check the Supabase connection string.

## 9. Current V3 features

Tablet-friendly responsive UI · PWA install support · subjects/topics/sources
· PDF/DOCX/TXT source ingestion · layered AI pipeline (extract → teach →
flashcard → question → validate) · AI-graded testing with error
classification · adaptive revision priority · flashcard review queue · Anki
CSV export · PDF notes export · cloud PostgreSQL with local SQLite fallback ·
password protection · health endpoint for hosting platforms.

## 10. Possible next stages

Full syllabus/coverage map across all SSC CGL subjects · daily planner tied
to exam date and mastery · timed tests with configurable negative marking ·
spaced-repetition due-dates for flashcards · full study-database backup/
restore · batch processing for large source libraries.
